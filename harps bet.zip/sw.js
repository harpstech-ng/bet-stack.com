const CACHE_NAME = 'betstack-v1';
const ASSETS = [
  './',
  './index.html',
  './login.html',
  './pricing.html',
  './dashboard.html',
  './terms.html',
  './privacy.html',
  './contact.html',
  './icon-192.png',
  './icon-512.png',
  './og-image.png',
  './manifest.json'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(res => res || fetch(e.request))
  );
});